Visit our discord: https://discord.gg/nVfDBy97aK

============

Installation:

1. Move "dinput8.dll" file to "BLUEPROTOCOL\Binaries\Win64" folder.

2. Make sure to delete "~mods" folder in "BLUEPROTOCOL\Content\Paks" folder.

3. Move "~mods" folder to "BLUEPROTOCOL\Content\Paks" folder.

4. Move "server-patch" folder to any location convenient for you.

============

Translation (client-patch):

The game will automatically have translation patch if following installation step.

============

Translation (server-patch):

1. Open "bp-translate.exe" file.
Note: It is necessary to open each time before you open the game.

2. Launch the game as usual from the launcher.

3. Wait till "Translation sent, the program will close" message shown up, and the window will automatically close after the game launched.

4. The game will have translation patch.

============

Uninstall:

1. Delete "dinput8.dll" file in "BLUEPROTOCOL\Binaries\Win64" folder.

2. Delete "~mods" folder in "BLUEPROTOCOL\Content\Paks" folder.

3. Delete "server-patch" folder in location you've moved the folder before.

